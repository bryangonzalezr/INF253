Nombre: Bryan Felipe González Ramírez
Rol: 202073052-0


Instrucciones del archivo:

Abrir el programa movmariolp.py. El programa funciona como interprete del lenguaje
MovMarioLp.

Para ejecutar satisfactoriamente, se debe tener el codigo en lenguaje MovMarioLp, escrito
dentro de un archivo codigo.txt que se encuentre en la misma carpeta que el programa.

El lenguaje solo acepta la sintaxis especificada en el EBNF del lenguaje, y si existen lineas 
mal escritas, estas seran enviadas a una archivo errores.txt que sera creado en la misma carpeta
contenedora.

Este programa interpreta desde los parentesis mas internos, de izquierda a derecha, por lo que 
debe tener esto en cuenta a la hora de crear un codigo en este lenguaje.