public interface Enemigo {
    
    //Metodo combate//
    //Interfaz para implementar el combate en el Jefe_Final y en Monstruo//
    void combate(Jugador player);
}
